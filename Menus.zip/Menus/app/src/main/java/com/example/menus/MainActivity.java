package com.example.menus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtMensaje;
    EditText edtCaptura;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtMensaje = findViewById(R.id.txtMensaje);
        edtCaptura = findViewById(R.id.edtCaptura);
        registerForContextMenu(edtCaptura);



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        txtMensaje.setText("");
        switch(item.getItemId()){
            case R.id.item_uno: txtMensaje.setText("Seleccionaste la opcion 1"); break;
            case R.id.item_dos: txtMensaje.setText("Seleccionaste la opcion 2"); break;
            case R.id.item_tres: txtMensaje.setText("Seleccionaste la opcion 3"); break;
            case R.id.item_cuatro: txtMensaje.setText("Seleccionaste la opcion 4"); break;
            case R.id.item_cinco: txtMensaje.setText("Seleccionaste la opcion 5"); break;
         }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        menu.setHeaderTitle("Menu Contextual");
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.my_options_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);

    }


    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {

        txtMensaje.setText("");
        switch (item.getItemId()){
            case R.id.item_cdos: txtMensaje.setText("Eligio el contextual 2"); break;
            case R.id.item_ctres: txtMensaje.setText("Elegiste el contextual 3"); break;
            case R.id.item_cuatro: txtMensaje.setText("Seleccionaste la opcion 3"); break;
            case R.id.item_cinco: txtMensaje.setText("Eligio el contextual 3"); break;
            case R.id.item_seis: txtMensaje.setText("Eligio el contextual 3"); break;


        }
        return super.onContextItemSelected(item);
    }
}