package com.example.sharedpreferences;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private SharedPreferences misDatos;
    private EditText edtNombre, edtCordX, edtCordY, edtReporte;
    private String nombre;
    private Float x,y;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNombre = findViewById(R.id.edtNombre);
        edtCordX = findViewById(R.id.edtCordX);
        edtCordY = findViewById(R.id.edtCoordY);
        edtReporte = findViewById(R.id.edtReporte);

        misDatos = getSharedPreferences("preferencias",MODE_PRIVATE );
        nombre = misDatos.getString("nombre", "Valor por default");
        x = misDatos.getFloat("x", 0.0f);
        y = misDatos.getFloat("y", 0.0f);

        edtReporte.append("Preferencias restauradas al reactivar la actividad. \n");
    }

    @Override
    protected void onPause() {
        super.onPause();
        nombre = edtNombre.getText().toString();
        x = Float.parseFloat(edtCordX.getText().toString());
        y = Float.parseFloat(edtCordY.getText().toString());
        SharedPreferences.Editor editor = misDatos.edit();
        editor.putString("nombre", nombre);
        editor.putFloat("x",x);
        editor.putFloat("y",y);
        editor.apply();
        edtReporte.append("Preferencias Guardadas en onPause()  ");
        Toast.makeText(this, "Preferencias Guardadas", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {

        super.onResume();
        misDatos = getSharedPreferences("preferencias",MODE_PRIVATE );
        nombre = misDatos.getString("nombre", "Valor por default");
        x = misDatos.getFloat("x", 0.0f);
        y = misDatos.getFloat("y", 0.0f);

        edtReporte.append("Preferencias restauradas al reactivar la actividad. \n");
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState, @NonNull PersistableBundle outPersistentState) {
        SharedPreferences.Editor editor = misDatos.edit();
        editor.putString("Clave","Valor");
        editor.commit();
        super.onSaveInstanceState(outState, outPersistentState);
    }
}